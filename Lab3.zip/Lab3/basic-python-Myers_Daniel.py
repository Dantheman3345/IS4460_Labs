
#This is a single line comment.

print("Hello World!")

print("Chewbacca")

print(3.4)

5+5

a = 5
b = 6

print(a+b)

a=9
A=3
b=2
B=4
g=(a^2+A) * (b^2 +B)
print(g)

print(type(B))

print(type(4.0))

number = 12345 * 67890
print(str(number)[1:3])

def add_some_numbers(a,b,c):
  print(a+b+c)
c=25

print(a)

add_some_numbers(a,b,c)
add_some_numbers(4,2,5)
print(b)

name = "guy"
def say():
  name = "jill"
  return "hello" + " " + name
say()